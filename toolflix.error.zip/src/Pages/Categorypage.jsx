// import React, { useEffect, useState } from 'react';
// import { useParams, Link } from 'react-router-dom';
// import axios from 'axios';
// import Navbar from '../Components/Navbar/Navbar';
// import { motion } from 'framer-motion';
// import Footer from '../Components/Footer/Footer';

// const CategoryVideos = () => {
//   const { id } = useParams(); // category id
//   const [videos, setVideos] = useState([]);
//   const [categoryName, setCategoryName] = useState('');
//   const [loading, setLoading] = useState(true);
// console.log(id,"===id====")
// //   useEffect(() => {
// //     axios.get('https://www.demo-new.toon-flix.com/api/little')
// //       .then(res => {
// //         const allVideos = res.data.videos;
// //         const categories = res.data.categories;

// //         // Filter videos by category id
// //         const filtered = allVideos.filter(v => v.sub_category_id.toString() === id);
// //         setVideos(filtered);

// //         // Get category name
// //         const cat = categories.find(c => c.id.toString() === id);
// //         setCategoryName(cat?.name || 'Category');
// //       })
// //       .catch(err => console.error("Error fetching category:", err))
// //       .finally(() => setLoading(false));
// //   }, [id]);



// useEffect(() => {
//   setLoading(true); // Make sure it resets when category changes

//   axios.get('https://www.demo-new.toon-flix.com/api/little')
//     .then(res => {
//       const allVideos = res.data.videos || [];
//       const categories = res.data.categories || [];

//       // Always convert to string for reliable comparison
//       const filtered = allVideos.filter(
//         (v) => v.sub_category_id?.toString() === id.toString()
//       );
//       setVideos(filtered);

//       const cat = categories.find((c) => c.id?.toString() === id.toString());
//       setCategoryName(cat?.name || 'Category');
//     })
//     .catch((err) => {
//       console.error("Error fetching category:", err);
//       setVideos([]);
//       setCategoryName("Category");
//     })
//     .finally(() => {
//       setLoading(false);
//     });
// }, [id]);

//   return (
//     <>
//     <Navbar/>
//     <div className="min-h-screen p-6 mt-10">
//       <Link to="/" className="text-blue-600 hover:underline mb-4 inline-block">← Back to Gallery</Link>

//       <h1 className="text-3xl font-bold text-center text-[#565ccc] mb-6">
//         {categoryName} Videos
//       </h1>

//       {loading ? (
//            <div className="w-full gap-x-2 flex justify-center items-center">
//       <div className="w-5 bg-[#d991c2] animate-pulse h-5 rounded-full animate-bounce" />
//       <div className="w-5 animate-pulse h-5 bg-[#9869b8] rounded-full animate-bounce" />
//       <div className="w-5 h-5 animate-pulse bg-[#6756cc] rounded-full animate-bounce" />
//     </div>
  
//       ) : videos.length === 0 ? (
//         <p className="text-center">No videos found in this category.</p>
//       ) : (
//         <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
//           {videos.map((video) => (
// <Link to={`/video/${video.id}`} key={video.id}>
             
//                  <motion.div
//                   className="flex flex-col rounded-xl bg-white text-gray-700 shadow-md"
//                   initial={{ opacity: 0, y: 30 }}
//                   whileInView={{ opacity: 1, y: 0 }}
//                   whileHover={{ scale: 1.05 }}
//                   transition={{ duration: 0.4, ease: 'easeOut' }}
//                   viewport={{ once: true }}
//                 >
//                 <img
//                   src={video.imgurl}
//                   alt={video.name}
//                   className="w-full h-48 object-cover"
//                 />
//                 <div className="p-4">
//                   <h2 className="text-lg font-semibold">{video.name}</h2>
//                   <p className="text-sm text-gray-600">{video.description}</p>
//                 </div>
//               </motion.div>
//             </Link>
//           ))}
//         </div>
//       )}
//       <div className='flex justify-center'>
//         <button  onClick={() => (window.location.href = '/')}
//         className="bg-[#696fd4] text-center w-48 rounded-2xl h-14 relative text-white text-xl font-semibold group" type="button">
//       <div className="bg-[#b2b6ff] rounded-xl h-12 w-1/4 flex items-center justify-center absolute left-1 top-[4px] group-hover:w-[184px] z-10 duration-500">
//         <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" height="25px" width="25px">
//           <path d="M224 480h640a32 32 0 1 1 0 64H224a32 32 0 0 1 0-64z" fill="#000000" />
//           <path d="m237.248 512 265.408 265.344a32 32 0 0 1-45.312 45.312l-288-288a32 32 0 0 1 0-45.312l288-288a32 32 0 1 1 45.312 45.312L237.248 512z" fill="#000000" />
//         </svg>
//       </div>
//       <p className="translate-x-2">Go Back</p>
//     </button>
//     </div>
//     </div>
//     <Footer/>
//     </>
//   );
// };

// export default CategoryVideos;



import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom'; // added useNavigate
import axios from 'axios';
import Navbar from '../Components/Navbar/Navbar';
import { motion } from 'framer-motion';
import Footer from '../Components/Footer/Footer';

const CategoryVideos = () => {
  const { id } = useParams(); // category id
  // console.log(id,"==id==")
  const [videos, setVideos] = useState([]);
  // console.log(videos,"==videos==")
  const [categoryName, setCategoryName] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate(); // initialize navigate

//  useEffect(() => {
//   setLoading(true); // Show loading indicator
//   axios.get('https://kids.toon-flix.com/videoFrench')
//     .then(res => {
//       const allVideos = res.data.videos || [];
//       const categories = res.data.categories || [];

//       console.log("All Videos:", allVideos);
//       console.log("Categories:", categories);
//       console.log("Route ID:", id);

//       // ✅ Filter videos by category_id (not sub_category_id)
//       const filtered = allVideos.filter(
//         (v) => Number(v.category_id) === Number(id)
//       );

//       setVideos(filtered);
//       console.log("Filtered Videos:", filtered);

//       // ✅ Find category name from categories
//       const cat = categories.find((c) => Number(c.id) === Number(id));
//       setCategoryName(cat?.name || 'Category');
//     })
//     .catch((err) => {
//       console.error("Error fetching category:", err);
//       setVideos([]);
//       setCategoryName("Category");
//     })
//     .finally(() => {
//       setLoading(false);
//     });
// }, [id]);

useEffect(() => {
    const fetchData = async () => {
      setLoading(true); // Show loading indicator

      try {
        const res = await axios.get('https://kids.toon-flix.com/videoFrench');
        console.log(res, "==response==");
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false); // Hide loading indicator
      }
    };

    fetchData();
  }, []);



  return (
    <>
      <Navbar />
      <div className="min-h-screen p-6 mt-10">
        <Link to="/" className="text-blue-600 hover:underline mb-4 inline-block">← Back to Gallery</Link>

        <h1 className="text-3xl font-bold text-center text-[#565ccc] mb-6">
          {categoryName} Videos
        </h1>

        {loading ? (
          // Loading animation shown only while loading
          <div className="w-full gap-x-2 flex justify-center items-center py-10">
            <div className="w-5 bg-[#d991c2] animate-pulse h-5 rounded-full animate-bounce" />
            <div className="w-5 animate-pulse h-5 bg-[#9869b8] rounded-full animate-bounce" />
            <div className="w-5 h-5 animate-pulse bg-[#6756cc] rounded-full animate-bounce" />
          </div>
        ) : videos.length === 0 ? (
          // No videos message when not loading
          <p className="text-center">No videos found in this category.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {videos.map((video) => (
              <Link to={`/video/${video.id}`} key={video.id}>
                <motion.div
                  className="flex flex-col rounded-xl bg-white text-gray-700 shadow-md"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.4, ease: 'easeOut' }}
                  viewport={{ once: true }}
                >
                  <img
                    src={video.imgurl}
                    alt={video.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-4">
                    <h2 className="text-lg font-semibold">{video.name}</h2>
                    <p className="text-sm text-gray-600">{video.description}</p>
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        )}

        {/* Button only visible when not loading */}
        {!loading && (
          <div className='flex justify-center mt-8'>
            <button
              onClick={() => navigate('/')} // navigate to homepage
              className="bg-[#696fd4] text-center w-48 rounded-2xl h-14 relative text-white text-xl font-semibold group"
              type="button"
            >
              <div className="bg-[#b2b6ff] rounded-xl h-12 w-1/4 flex items-center justify-center absolute left-1 top-[4px] group-hover:w-[184px] z-10 duration-500">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" height="25px" width="25px">
                  <path d="M224 480h640a32 32 0 1 1 0 64H224a32 32 0 0 1 0-64z" fill="#000000" />
                  <path d="m237.248 512 265.408 265.344a32 32 0 0 1-45.312 45.312l-288-288a32 32 0 0 1 0-45.312l288-288a32 32 0 1 1 45.312 45.312L237.248 512z" fill="#000000" />
                </svg>
              </div>
              <p className="translate-x-2">Go Back</p>
            </button>
          </div>
        )}
      </div>
      <Footer />
    </>
  );
};

export default CategoryVideos;
