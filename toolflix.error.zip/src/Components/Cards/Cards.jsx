import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const Cards = () => {
  const [cards, setCards] = useState([]);
  // console.log(cards,"===cards====")
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('https://kids.toon-flix.com/videoFrench')
      .then((response) => {
        const result = response.data;

        if (Array.isArray(result.videos)) {
          setCards(result.videos);
        } else {
          console.error('Unexpected API structure:', result);
        }
      })
      .catch((error) => {
        console.error('Error fetching cards:', error);
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  return (
    <div className="w-full min-h-screen">
      <h1 className="text-center font-bold text-5xl text-[#EF7D00] leading-tight drop-shadow-md">
        Popular Cartoons
      </h1>

      <div className="w-full my-32 px-6">
        {loading ? (
          <p className="text-center text-lg">Loading...</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 -mt-20 gap-6">
            {cards.map((card, index) => (
                         <Link to={`/video/${card.id}`} key={index}>
                <motion.div
                  className="flex flex-col rounded-xl bg-white text-gray-700 shadow-md"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.4, ease: 'easeOut' }}
                  viewport={{ once: true }}
                >
                  <div className="h-40 overflow-hidden rounded-t-xl">
                    <img
                      src={card.imgurl}
                      alt={card.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-4">
                    <h5 className="text-lg font-semibold text-blue-gray-900">
                      {card.name}
                    </h5>
                    {/* <p className="text-sm text-gray-600">
                      {card.description || 'Enjoy fun and educational cartoon adventures!'}
                    </p> */}
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Cards;



