// import { useState, useEffect } from 'react';

// const Searchbar = () => {
//   const [query, setQuery] = useState('');
//   const [results, setResults] = useState([]);

//   useEffect(() => {
//     const fetchData = async () => {
//       if (query.trim() === '') {
//         setResults([]);
//         return;
//       }

//       try {
//         const res = await fetch(`https://www.demo-new.toon-flix.com/api/little?search=${encodeURIComponent(query)}`);
//         const data = await res.json();
//         setResults(data);
//       } catch (error) {
//         console.error('Error fetching data:', error);
//       }
//     };

//     // Delay the request a bit (debounce)
//     const delayDebounce = setTimeout(() => {
//       fetchData();
//     }, 300); // 300ms delay

//     return () => clearTimeout(delayDebounce);
//   }, [query]);

//   return (
//     // <div style={{ padding: '1rem' }}>
//     //   <input
//     //     type="text"
//     //     placeholder="Search..."
//     //     value={query}
//     //     onChange={e => setQuery(e.target.value)}
//     //     style={{ padding: '8px', width: '300px', borderRadius: '4px', border: '1px solid #ccc' }}
//     //   />
//     //   <div style={{ marginTop: '1rem' }}>
//     //     {results.length === 0 && query && <p>No results found.</p>}
//     //     {results.map((item, index) => (
//     //       <div key={index} style={{ padding: '6px 0' }}>
//     //         {item.title || JSON.stringify(item)}
//     //       </div>
//     //     ))}
//     //   </div>
//     // </div>
//     <div className="hidden sm:flex flex-grow mx-4 relative max-w-2xl w-full">
//   <input
//     type="text"
//     placeholder="Search..."
//     value={searchQuery}
//     onChange={(e) => setSearchQuery(e.target.value)}
//     className="w-full py-2 pl-4 pr-12 rounded-lg text-gray-700 border border-transparent hover:border-white focus:border-yellow-300 outline-none transition duration-200"
//   />
//   <button className="absolute right-2 top-1/2 -translate-y-1/2 text-yellow-500">
//     <Search />
//   </button>

//   {searchResults.length > 0 && (
//     <div className="absolute top-12 left-0 right-0 bg-white text-black mt-1 max-h-60 overflow-y-auto rounded shadow-lg border border-gray-300 z-[9999]">
//       {searchResults.map((item, index) => (
//         <div key={index} className="p-2 border-b hover:bg-gray-100 text-sm">
//           {item.title || "Untitled"}
//         </div>
//       ))}
//     </div>
//   )}
// </div>

//   );
// };

// export default Searchbar;


// import { useState, useEffect } from "react";
// import axios from "axios";
// import { Search } from "lucide-react";

// export default function Searchbar() {
//   const [searchQuery, setSearchQuery] = useState("");
//   const [searchResults, setSearchResults] = useState([]);

//   useEffect(() => {
//     const delayDebounce = setTimeout(() => {
//       if (searchQuery.trim() === "") {
//         setSearchResults([]);
//         return;
//       }

//       axios
//         .get(`https://www.demo-new.toon-flix.com/api/little?search=${encodeURIComponent(searchQuery)}`)
//         .then((res) => {
//           if (Array.isArray(res.data)) {
//             setSearchResults(res.data);
//           } else {
//             setSearchResults([]);
//           }
//         })
//         .catch((err) => {
//           console.error("Error fetching search results:", err);
//         });
//     }, 300);

//     return () => clearTimeout(delayDebounce);
//   }, [searchQuery]);

//   return (
//     <div className="relative w-full max-w-2xl mx-auto">
//       <input
//         type="text"
//         placeholder="Search..."
//         value={searchQuery}
//         onChange={(e) => setSearchQuery(e.target.value)}
//         className="w-full py-2 pl-4 pr-12 rounded-lg text-gray-700 border border-transparent hover:border-white focus:border-yellow-300 outline-none transition duration-200"
//       />
//       <button className="absolute right-2 top-1/2 -translate-y-1/2 text-yellow-500">
//         <Search />
//       </button>

//       {searchResults.length > 0 && (
//         <div className="absolute top-12 left-0 right-0 bg-white text-black mt-1 max-h-60 overflow-y-auto rounded shadow-lg border border-gray-300 z-[9999]">
//           {searchResults.map((item, index) => (
//             <div key={index} className="p-2 border-b hover:bg-gray-100 text-sm">
//               {item.title || "Untitled"}
//             </div>
//           ))}
//         </div>
//       )}
//     </div>
//   );
import { useState, useEffect } from "react";
import axios from "axios";
import { Search } from "lucide-react";

export default function Searchbar() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [showDropdown, setShowDropdown] = useState(false);

  useEffect(() => {
    const delayDebounce = setTimeout(() => {
      if (query.trim() === "") {
        setResults([]);
        setShowDropdown(false);
        return;
      }

      axios
        .get(`https://www.demo-new.toon-flix.com/api/little?search=${encodeURIComponent(query)}`)
        .then((res) => {
          if (Array.isArray(res.data)) {
            setResults(res.data);
            setShowDropdown(true);
          } else {
            setResults([]);
            setShowDropdown(false);
          }
        })
        .catch((err) => {
          console.error("Error fetching data:", err);
          setResults([]);
          setShowDropdown(false);
        });
    }, 300);

    return () => clearTimeout(delayDebounce);
  }, [query]);

  return (
    <div className="relative w-full max-w-2xl">
      <input
        type="text"
        placeholder="Search..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="w-full py-2 pl-4 pr-12 rounded-lg text-gray-700 border border-transparent hover:border-white focus:border-yellow-300 outline-none transition duration-200"
      />
      <button className="absolute right-2 top-1/2 -translate-y-1/2 text-yellow-500">
        <Search />
      </button>

      {/* Suggestions dropdown */}
      {showDropdown && results.length > 0 && (
        <div className="absolute top-12 left-0 right-0 bg-white text-black mt-1 max-h-60 overflow-y-auto rounded shadow-lg border border-gray-300 z-[9999]">
          {results.map((item, index) => (
            <div key={index} className="p-2 border-b hover:bg-gray-100 text-sm cursor-pointer">
              {item.title || "Untitled"}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

