
import { Search, Menu } from "lucide-react";
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import "./Navbar.css";
import Searchbar from "../Searchbar";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [categories, setCategories] = useState([]);
  console.log(categories,"==categories")
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);

  useEffect(() => {
    axios
      .get("https://kids.toon-flix.com/videoFrench")
      .then((res) => {
        if (Array.isArray(res.data.categories)) {
          const filtered = res.data.categories.filter((item) => item.id != 74);
          setCategories(filtered);
          console.log(filtered,"==filtered==")
        }
      })
      .catch((err) => console.error("Error loading categories:", err));
  }, []);

  useEffect(() => {
    const delayDebounce = setTimeout(() => {
      if (searchQuery.trim() === "") {
        setSearchResults([]);
        return;
      }

      axios
        // .get(`https://www.demo-new.toon-flix.com/api/little?search=${encodeURIComponent(searchQuery)}`)
          
        .then((res) => {
          // console.log(res,"==responsre---")
          if (Array.isArray(res.data)) {
            setSearchResults(res.data);
          } else {
            setSearchResults([]);
          }
        })
        .catch((err) => {
          console.error("Error searching:", err);
          setSearchResults([]);
        });
    }, 300); // debounce delay

    return () => clearTimeout(delayDebounce);
  }, [searchQuery]);

  return (
    <>
    <Searchbar/>
      <nav className="fixed top-0 w-full z-50 bg-[#005DAA] text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between flex-wrap">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <img src="/logooo.png" alt="Kiddy Logo" className="h-28 sm:h-28 md:h-40" />
          </div>

          {/* Toggle for Mobile */}
          <button
            className="md:hidden text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Menu />
          </button>

          {/* Search Bar */}
          <div className="hidden sm:flex flex-grow mx-4 relative max-w-2xl w-full">
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full py-2 pl-4 pr-12 rounded-lg text-gray-700 border border-transparent hover:border-white focus:border-[#EF7D00] outline-none transition duration-200"
            />
            <button className="absolute right-2 top-1/2 -translate-y-1/2 text-[#EF7D00]">
              <Search />
            </button>

            {/* Search Results Dropdown */}
            {searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 bg-white text-black mt-2 max-h-60 overflow-y-auto rounded shadow-lg z-50">
                {searchResults.map((item, index) => (
                  <div key={index} className="p-2 border-b hover:bg-gray-100 text-sm">
                    {item.title || "Untitled"}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Login Button */}
          <div className="hidden lg:flex items-center">
            <button className="btn">Login</button>
          </div>
        </div>

        {/* Navigation Links */}
        <div
          className={`${
            isMenuOpen ? "block" : "hidden"
          } md:flex bg-[#005DAA] text-white px-4 pb-4 -mt-8 mb-8 md:pb-0 justify-center flex-wrap space-x-0 md:space-x-4 font-medium text-lg transition-all duration-300`}
        >
          <Link
            to="/"
            className="block md:inline hover:p-2 hover:bg-[#EF7D00] hover:text-white hover:rounded-lg transition-all duration-300 px-2 py-1"
          >
            Home
          </Link>

          {categories.map((cat) => (
            <Link
              key={cat.id}
              to={`/category/${cat.id}`}
              className="block md:inline hover:p-2 hover:bg-[#EF7D00] hover:text-white hover:rounded-lg transition-all duration-300 px-2 py-1"
            >
              {cat.name}
            </Link>
          ))}

          {/* Login for Mobile */}
          <div className="sm:hidden mt-3 text-center">
            <button className="btn">Login</button>
          </div>
        </div>

        {/* Decorative border */}
        <div className="bg-white h-8 w-full -mt-1 rounded-t-[50%]"></div>
      </nav>

      {/* Offset for fixed navbar */}
      <div className="lg:pt-22 pt-20"></div>
    </>
  );
}
