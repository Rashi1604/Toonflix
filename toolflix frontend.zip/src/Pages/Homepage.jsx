import React from 'react'
import Navbar from '../Components/Navbar/Navbar'
import HeroSection from '../Components/Hero/Hero'
import Cards from '../Components/Cards/Cards'
import CardVideos from '../Components/Cards/CardVideos'
import Footer from '../Components/Footer/Footer'
const Homepage = () => {
  return (
    <div>
      <Navbar/>
     <HeroSection/>
    <Cards/>
    <CardVideos/>
    <Footer/>
    </div>
  )
}

export default Homepage
