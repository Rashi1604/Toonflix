import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';

const CategoryVideos = () => {
  const { id } = useParams(); // category id
  const [videos, setVideos] = useState([]);
  const [categoryName, setCategoryName] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('https://www.demo-new.toon-flix.com/api/little')
      .then(res => {
        const allVideos = res.data.videos;
        const categories = res.data.categories;

        // Filter videos by category id
        const filtered = allVideos.filter(v => v.sub_category_id.toString() === id);
        setVideos(filtered);

        // Get category name
        const cat = categories.find(c => c.id.toString() === id);
        setCategoryName(cat?.name || 'Category');
      })
      .catch(err => console.error("Error fetching category:", err))
      .finally(() => setLoading(false));
  }, [id]);

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <Link to="/" className="text-blue-600 hover:underline mb-4 inline-block">← Back to Gallery</Link>

      <h1 className="text-3xl font-bold text-center text-[#565ccc] mb-6">
        {categoryName} Videos
      </h1>

      {loading ? (
        <p className="text-center">Loading...</p>
      ) : videos.length === 0 ? (
        <p className="text-center">No videos found in this category.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {videos.map((video) => (
            <Link to={`/video/${video.id}`} key={video.id}>
              <div className="bg-white rounded shadow hover:shadow-lg overflow-hidden">
                <img
                  src={video.imgurl}
                  alt={video.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h2 className="text-lg font-semibold">{video.name}</h2>
                  <p className="text-sm text-gray-600">{video.description}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
};

export default CategoryVideos;
