import React from 'react'

const Footer = () => {
  return (
    <div>
      <footer className="bg-gray-500 text-white py-6 ">
  <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <div className="flex flex-col md:flex-row justify-center items-center">
      <div className="mb-4 md:mb-0">
        <h2 className="text-lg font-bold ml-10 ">ToonFlix</h2>
        <p className="text-sm text-white">2025 All rights reserved.</p>
      </div>
    </div>
  </div>
</footer>
    </div>
  )
}

export default Footer
