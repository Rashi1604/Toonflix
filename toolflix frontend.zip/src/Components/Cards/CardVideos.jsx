import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import ReactPlayer from 'react-player';

const CardsVideos = () => {
  const { id } = useParams();
  const [video, setVideo] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios
      .get('https://www.demo-new.toon-flix.com/api/little')
      .then((res) => {
        const found = res.data.videos.find((v) => v.id.toString() === id);
        setVideo(found);
      })
      .catch((err) => console.error('Error loading video:', err))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <p className="text-center mt-10">Loading video...</p>;

  if (!video) return <p className="text-center mt-10">Video not found.</p>;

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <Link to="/" className="text-blue-600 hover:underline mb-4 inline-block">← Back to Gallery</Link>
      <div className="bg-white rounded shadow p-6 max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-4">{video.name}</h1>
        <div className="mb-6">
          {/* <ReactPlayer url={video.} contrvideo_urlols width="100%" height="400px" /> */}
          <ReactPlayer url={video.vurl} controls playing={true} width="100%" height="400px" />

        </div>
        <p className="text-gray-700">{video.description}</p>
      </div>
    </div>
  );
};

export default CardsVideos;
