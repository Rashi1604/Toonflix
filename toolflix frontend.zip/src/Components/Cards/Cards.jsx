// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { motion } from 'framer-motion';
// import { Link } from 'react-router-dom';

// const Cards = () => {
//   const [cards, setCards] = useState([]);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     axios.get('https://www.demo-new.toon-flix.com/api/little')
//       .then((response) => {
//         const result = response.data;

//         if (Array.isArray(result.videos)) {
//           setCards(result.videos);
//         } else {
//           console.error('Unexpected API structure:', result);
//         }
//       })
//       .catch((error) => {
//         console.error('Error fetching cards:', error);
//       })
//       .finally(() => {
//         setLoading(false);
//       });
//   }, []);

//   return (
//     <div className="w-full min-h-screen">
//       <h1 className="text-center font-bold text-5xl text-[#565ccc] leading-tight drop-shadow-md">
//         Popular Cartoons
//       </h1>

//       <div className="w-full my-32 px-6">
//         {loading ? (
//           <p className="text-center text-lg">Loading...</p>
//         ) : (
//           <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 -mt-20 gap-6">
//             {cards.map((card, index) => (
//               <Link to="#" key={index}>
//                 <motion.div
//                   className="flex flex-col rounded-xl bg-white text-gray-700 shadow-md"
//                   initial={{ opacity: 0, y: 30 }}
//                   whileInView={{ opacity: 1, y: 0 }}
//                   whileHover={{ scale: 1.05 }}
//                   transition={{ duration: 0.4, ease: 'easeOut' }}
//                   viewport={{ once: true }}
//                 >
//                   <div className="h-40 overflow-hidden rounded-t-xl">
//                     <img
//                       src={card.imgurl}
//                       alt={card.name}
//                       className="w-full h-full object-cover"
//                     />
//                   </div>
//                   <div className="p-4">
//                     <h5 className="text-lg font-semibold text-blue-gray-900">
//                       {card.name}
//                     </h5>
//                     <p className="text-sm text-gray-600">
//                       {card.description || 'Enjoy fun and educational cartoon adventures!'}
//                     </p>
//                   </div>
//                 </motion.div>
//               </Link>
//             ))}
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default Cards;




import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Cards = () => {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios
      .get('https://www.demo-new.toon-flix.com/api/little')
      .then((res) => {
        if (Array.isArray(res.data.videos)) {
          setVideos(res.data.videos);
        }
      })
      .catch((err) => console.error('API Error:', err))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen  p-6">
      <h1 className="text-4xl font-bold text-center text-[#565ccc] mb-8">Video Gallery</h1>

      {loading ? (
        <p className="text-center text-lg">Loading...</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {videos.map((video, index) => (
            <Link to={`/video/${video.id}`} key={index}>
              <div className="bg-white rounded shadow hover:shadow-lg cursor-pointer overflow-hidden">
                <img
                  src={video.imgurl || 'https://via.placeholder.com/400x300'}
                  alt={video.name}
                  className="h-48 w-full object-cover"
                />
                <div className="p-4">
                  <h2 className="text-lg font-semibold text-gray-800">{video.name}</h2>
                  <p className="text-sm text-gray-600 truncate">{video.description}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
};

export default Cards;




