// import { Search, ShoppingCart, Menu } from "lucide-react";
// import { useState } from "react";
// import "./Navbar.css";

// export default function Navbar() {
//   const [isMenuOpen, setIsMenuOpen] = useState(false);

//   return (
//     <>
//       <nav className="fixed top-0 w-full z-50 bg-[#565ccc] text-white overflow-hidden ">
//         {/* Top Section */}
//         <div className="max-w-7xl mx-auto px-4  flex items-center justify-between flex-wrap">
//           {/* Left: Logo */}
//           <div className="flex items-center space-x-3">
//             <img src="logooo.png" alt="Kiddy Logo" className="h-28  sm:h-28 md:h-40" />
//           </div>

//           {/* Toggle Button for Mobile */}
//           <button
//             className="sm:hidden text-white"
//             onClick={() => setIsMenuOpen(!isMenuOpen)}
//           >
//             <Menu />
//           </button>

//           {/* Center: Search Bar */}
//           <div className="hidden sm:flex flex-grow mx-4 relative max-w-2xl w-full">
//             <input
//               type="text"
//               placeholder="Search..."
//               className="w-full py-2 pl-4 pr-12 rounded-lg text-gray-700 border border-transparent hover:border-white focus:border-yellow-300 outline-none transition duration-200"
//             />
//             <button className="absolute right-2 top-1/2 -translate-y-1/2 text-yellow-500">
//               <Search />
//             </button>
//           </div>

//           {/* Right: Login Button */}
//           <div className="hidden sm:flex items-center">
//             <button className="btn">Login</button>
//           </div>
//         </div>

//         {/* Bottom Navigation */}
//         <div
//           className={`${
//             isMenuOpen ? "block" : "hidden"
//           } sm:flex bg-[#565ccc] text-white px-4 pb-4 -mt-8 mb-8 sm:pb-0 justify-center flex-wrap space-x-0 sm:space-x-4 font-medium text-lg transition-all duration-300`}
//         >
//           {[
//             "Home",
//             "Green Light",
//             "Pumpkin Reports",
//             "LMNs",
//             "Telmo & Tula-Art & Crafts",
//             "Telmo & Tula-Little Cooks",
//             "GLUMPERS",
//             "Raindrop",
//             "Van Dough",
//           ].map((text, index) => (
//             <a
//               key={index}
//               href="#"
//               className="block sm:inline hover:p-2 hover:bg-white hover:text-[#565ccc] hover:rounded-lg transition-all duration-300 px-2 py-1"
//             >
//               {text}
//             </a>
//           ))}

//           {/* Login for Mobile */}
//           <div className="sm:hidden mt-3 text-center">
//             <button className="btn">Login</button>
//           </div>
//         </div>

//         {/* Slime-style border effect */}
//         <div className="bg-white h-8 w-full -mt-1 rounded-t-[50%]"></div>
//       </nav>

//       {/* Padding to offset fixed navbar height */}
//       <div className="lg:pt-22 pt-20"></div>
//     </>
//   );
// }
import { Search, ShoppingCart, Menu } from "lucide-react";
import { useState } from "react";
import "./Navbar.css";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <>
      <nav className="fixed top-0 w-full z-50 bg-[#565ccc] text-white overflow-hidden ">
        {/* Top Section */}
        <div className="max-w-7xl mx-auto px-4  flex items-center justify-between flex-wrap">
          {/* Left: Logo */}
          <div className="flex items-center space-x-3">
            <img src="logooo.png" alt="Kiddy Logo" className="h-28  sm:h-28 md:h-40" />
          </div>

          {/* Toggle Button for Mobile */}
          <button
            className="sm:hidden text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Menu />
          </button>

          {/* Center: Search Bar */}
          <div className="hidden sm:flex flex-grow mx-4 relative max-w-2xl w-full">
            <input
              type="text"
              placeholder="Search..."
              className="w-full py-2 pl-4 pr-12 rounded-lg text-gray-700 border border-transparent hover:border-white focus:border-yellow-300 outline-none transition duration-200"
            />
            <button className="absolute right-2 top-1/2 -translate-y-1/2 text-yellow-500">
              <Search />
            </button>
          </div>

          {/* Right: Login Button */}
          <div className="hidden sm:flex items-center">
            <button className="btn">Login</button>
          </div>
        </div>

        {/* Bottom Navigation */}
        <div
          className={`${
            isMenuOpen ? "block" : "hidden"
          } sm:flex bg-[#565ccc] text-white px-4 pb-4 -mt-8 mb-8 sm:pb-0 justify-center flex-wrap space-x-0 sm:space-x-4 font-medium text-lg transition-all duration-300`}
        >
          {[
            "Home",
            "Green Light",
            "Pumpkin Reports",
            "LMNs",
            "Telmo & Tula-Art & Crafts",
            "Telmo & Tula-Little Cooks",
            "GLUMPERS",
            "Raindrop",
            "Van Dough",
          ].map((text, index) => (
            <a
              key={index}
              href="#"
              className="block sm:inline hover:p-2 hover:bg-white hover:text-[#565ccc] hover:rounded-lg transition-all duration-300 px-2 py-1"
            >
              {text}
            </a>
          ))}

          {/* Login for Mobile */}
          <div className="sm:hidden mt-3 text-center">
            <button className="btn">Login</button>
          </div>
        </div>

        {/* Slime-style border effect */}
        <div className="bg-white h-8 w-full -mt-1 rounded-t-[50%]"></div>
      </nav>

      {/* Padding to offset fixed navbar height */}
      <div className="lg:pt-22 pt-20"></div>
    </>
  );
}
